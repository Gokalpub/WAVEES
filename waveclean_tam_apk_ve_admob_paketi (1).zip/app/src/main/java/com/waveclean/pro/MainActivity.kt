package com.waveclean.pro

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var rewardedAd: RewardedAd? = null
    private var isLoadingRewarded = false
    private var isShowingAd = false
    private var pendingActionTag: String? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    // 1. Sizin Gerçek Google AdMob Ödüllü Reklam Birimi Kimliğiniz (Öncelikli):
    private val PRIMARY_REWARDED_UNIT_ID = "ca-app-pub-8819233961749663/5113916136"
    // 2. Uygulama henüz Google Play'de yayınlanmadığında "No Fill" dönerse devreye giren resmi yedek birim:
    private val FALLBACK_REWARDED_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidAdMobBridge(), "AndroidAdMob")
        webView.loadUrl("file:///android_asset/index.html")

        CoroutineScope(Dispatchers.IO).launch {
            MobileAds.initialize(this@MainActivity) {
                runOnUiThread {
                    loadRewardedAd(PRIMARY_REWARDED_UNIT_ID, isFallback = false)
                }
            }
        }
    }

    private fun loadRewardedAd(unitId: String, isFallback: Boolean) {
        if (isLoadingRewarded || rewardedAd != null) return
        isLoadingRewarded = true
        val adRequest = AdRequest.Builder().build()

        RewardedAd.load(
            this,
            unitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    rewardedAd = null
                    isLoadingRewarded = false
                    if (!isFallback) {
                        // Gerçek birim henüz Play Store onayı/envanteri bekliyorsa (No-Fill) yedek reklamı yükle:
                        loadRewardedAd(FALLBACK_REWARDED_UNIT_ID, isFallback = true)
                    } else if (pendingActionTag != null) {
                        // İnternet kapalıysa işlemi kilitlemeden başlat
                        val tag = pendingActionTag ?: "action"
                        pendingActionTag = null
                        grantRewardToWeb(tag)
                    }
                }

                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isLoadingRewarded = false
                    val waitingTag = pendingActionTag
                    if (waitingTag != null) {
                        pendingActionTag = null
                        showAdForEveryAction(waitingTag)
                    }
                }
            }
        )
    }

    private fun grantRewardToWeb(actionTag: String) {
        runOnUiThread {
            webView.evaluateJavascript(
                "window.onAdMobRewardGranted && window.onAdMobRewardGranted('$actionTag');",
                null
            )
        }
    }

    private fun showAdForEveryAction(actionTag: String) {
        if (isShowingAd) return
        val currentAd = rewardedAd
        if (currentAd == null) {
            // Reklam henüz yükleniyorsa beklemeye al ve yüklendiği salise otomatik aç
            pendingActionTag = actionTag
            loadRewardedAd(PRIMARY_REWARDED_UNIT_ID, isFallback = false)
            return
        }

        isShowingAd = true
        var rewardGranted = false

        currentAd.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                isShowingAd = false
                rewardedAd = null
                if (!rewardGranted) {
                    rewardGranted = true
                    grantRewardToWeb(actionTag)
                }
                // Bir sonraki işlem için hemen yeni reklamı arka planda hazırla
                loadRewardedAd(PRIMARY_REWARDED_UNIT_ID, isFallback = false)
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                isShowingAd = false
                rewardedAd = null
                if (!rewardGranted) {
                    rewardGranted = true
                    grantRewardToWeb(actionTag)
                }
                loadRewardedAd(PRIMARY_REWARDED_UNIT_ID, isFallback = false)
            }
        }

        currentAd.show(this, OnUserEarnedRewardListener {
            if (!rewardGranted) {
                rewardGranted = true
                grantRewardToWeb(actionTag)
            }
        })
    }

    inner class AndroidAdMobBridge {
        @JavascriptInterface
        fun triggerAdOnAction(actionTag: String) {
            mainHandler.post {
                showAdForEveryAction(actionTag)
            }
        }

        @JavascriptInterface
        fun showRewarded(modeName: String) {
            mainHandler.post {
                showAdForEveryAction(modeName)
            }
        }

        @JavascriptInterface
        fun showInterstitial() {
            mainHandler.post {
                showAdForEveryAction("cycle_complete")
            }
        }
    }
}
